'use client';

import { useState } from 'react';
import { Carousel, CarouselItem, CarouselControl, CarouselIndicators } from 'reactstrap';

const items = [
  {
    key: 1,
    src: '/images/img1.png'
  }
];

export default function CustomCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);

  const next = () => {
    if (animating) return;
    setActiveIndex((prevIndex) => (prevIndex + 1) % items.length);
  };

  const prev = () => {
    if (animating) return;
    setActiveIndex((prevIndex) => (prevIndex === 0 ? items.length - 1 : prevIndex - 1));
  };

  return (
    <Carousel activeIndex={activeIndex} next={next} previous={prev}>
      <CarouselIndicators items={items} activeIndex={activeIndex} onClickHandler={setActiveIndex} />
      {items.map((item) => (
        <CarouselItem key={item.key} onExiting={() => setAnimating(true)} onExited={() => setAnimating(false)}>
          <img src={item.src} alt={`Slide ${item.key}`} className="d-block w-100" />
        </CarouselItem>
      ))}
      <CarouselControl direction="prev" directionText="Previous" onClickHandler={prev} />
      <CarouselControl direction="next" directionText="Next" onClickHandler={next} />
    </Carousel>
  );
}
