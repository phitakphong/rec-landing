'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Navbar, NavbarBrand, Nav, NavItem, NavLink, NavbarText, Container, Button } from 'reactstrap';
import LanguageSwitcher from './LanguageSwitcher';

export default function CustomNavbar() {
  return (
    <Container>
      <Navbar  expand="md">
      
      <NavbarBrand href="/">
        <Image
          src="/logo.svg"
          alt="Logo"
          width={150}
          height={50}
          priority 
        />
      </NavbarBrand>
      <Nav className="me-auto" navbar>
        <NavItem className='mx-2'>
          <Link href="/home" className="nav-link">
            เกี่ยวกับเรา
          </Link>
        </NavItem>
        <NavItem className='mx-2'>
          <Link href="/home" className="nav-link">
            ผลิตภัณฑ์ของเรา
          </Link>
 
        </NavItem>
        <NavItem className='mx-2'>
          <Link href="/" className="nav-link">
              คำนวณความต้องการ REC
          </Link>
        </NavItem>
        <NavItem className='mx-2'>
          <Link href="/" className="nav-link">
            ข่าวประกาศ
          </Link>
        </NavItem>
        <NavItem className='mx-2'>
          <Link href="/" className="nav-link">
            คำถามที่พบบ่อย
          </Link>
        </NavItem>
      </Nav>
      <NavbarText>
        <LanguageSwitcher/>
      </NavbarText>
      <NavbarText className='mx-1'>
        <div style={{ borderLeft: '2px solid #1E1F4B4D', height: '30px' }} />
      </NavbarText>
      <NavbarText className='ms-3'>
          <Button outline color="primary" style={{width:120, height:50}}>
            ลงทะเบียน
          </Button>
      </NavbarText>
      <NavbarText className='ms-3'>
          <Button color="primary" style={{width:120, height:50}}>
            เข้าสู่ระบบ
          </Button>
      </NavbarText>
      </Navbar>
    </Container>
  );
}
