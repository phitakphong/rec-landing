'use client';

import { useTranslation } from "react-i18next";
import CustomCarousel from "../components/CustomCarousel";
import '../../../i18n/i18n';
import Image from "next/image";

export default function HomeContent() {
  const { t } = useTranslation("home"); 

  return (
    <>
      <CustomCarousel />
      <div className="container-fluid px-0 mt-5">
        <div className="row ps-5 pt-5 me-0">
          <div className="col-6 ps-5">
            <h1>{t("H_1")}</h1> 
            <p className="txt-body" dangerouslySetInnerHTML={{ __html: `&emsp;&emsp;${t("D_1")}` }}></p>
            <div className="col-12">
              <div className="d-flex align-items-start p-3">
                  <div className="me-3">
                    <Image 
                      src="/images/ic_thunder.svg" 
                      alt="ic_thunder" 
                      width={60} 
                      height={60} 
                    />
                  </div>
                  
                  <div>
                    <h5 className="fw-bold mb-1">
                      {t("H_1_1")}
                    </h5>
                    <p className="text-muted mb-0" dangerouslySetInnerHTML={{ __html: t("D_1_1") }}></p>
                  </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex align-items-start p-3">
                  <div className="me-3">
                    <Image 
                      src="/images/ic_thunder.svg" 
                      alt="ic_thunder" 
                      width={60} 
                      height={60} 
                    />
                  </div>
                  
                  <div>
                    <h5 className="fw-bold mb-1">
                      {t("H_1_2")}
                    </h5>
                    <p className="text-muted mb-0" dangerouslySetInnerHTML={{ __html: t("D_1_2") }}></p>
                  </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex align-items-start p-3">
                  <div className="me-3">
                    <Image 
                      src="/images/ic_thunder.svg" 
                      alt="ic_thunder" 
                      width={60} 
                      height={60} 
                    />
                  </div>
                  
                  <div>
                    <h5 className="fw-bold mb-1">
                      {t("H_1_3")}
                    </h5>
                    <p className="text-muted mb-0" dangerouslySetInnerHTML={{ __html: t("D_1_3") }}></p>
                  </div>
              </div>
            </div>
          </div>
          <div className="col-6 position-relative d-flex justify-content-end">
      
              <Image
                src="/images/green2.svg"
                alt="green2"
                width={500}
                height={500}
                priority
                className="position-absolute top-0 end-0"
              />

              <Image
                src="/images/green1.svg"
                alt="green1"
                width={450}
                height={450}
                priority
                className="position-absolute top-0 end-0 me-4"
              />
          </div>
        </div>
        <div className="container-fluid">
        <div className="row p-5">
            <div className="col-12 px-5">
              <h1>{t("H_2")}</h1> 
              <p className="txt-body" dangerouslySetInnerHTML={{ __html: `${t("D_2")}` }}></p>
            </div>
            <div className="col-12 px-0 position-relative" >
  
            <div
              className="bg-purple position-absolute start-50 top-50"
              style={{
                width:'80%',
                height: "0.5em",
                transform: "translate(-50%, -50%)" // ✅ อยู่กึ่งกลางทั้ง X และ Y
              }}
            ></div>

            <div className="row d-flex text-center position-relative" style={{ height: "100%" }}>
              
              <div className="col-md-3 d-flex flex-column align-items-center justify-content-center">
                <Image src="/images/netz1.svg" alt="netz1" height={250} width={250} priority />
              </div>

              {/* ✅ Column 2 */}
              <div className="col-md-3 d-flex flex-column align-items-center justify-content-center">
                <Image src="/images/netz2.svg" alt="netz2" height={250} width={250} priority />
              </div>

              <div className="col-md-3 d-flex flex-column align-items-center justify-content-center">
                <Image src="/images/netz3.svg" alt="netz3" height={250} width={250} priority />
              </div>

              <div className="col-md-3 d-flex flex-column align-items-center justify-content-center">
                <Image src="/images/netz4.svg" alt="netz4" height={250} width={250} priority />
              </div>

            </div>

          </div>

          </div>
        </div>
      </div>
    </>
  );
}
