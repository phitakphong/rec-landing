
"use client";
import { IBM_Plex_Sans_Thai } from "next/font/google";
import "bootstrap/dist/css/bootstrap.min.css";
import "../app/globals.css";
import MyNav from "./components/MyNav";
import I18nProvider from "./components/I18nProvider";
import { useEffect, useState } from "react";
import i18next from '../../i18n/i18n';
import { useTranslation } from "react-i18next";

const ibmPlexSansThai = IBM_Plex_Sans_Thai({
  subsets: ["thai", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-ibm-plex-sans-thai",
});

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const { i18n } = useTranslation();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (i18next.isInitialized) {
      setIsReady(true);
    }
  }, []);
  
  return (
    <html lang={isReady ? i18n.language : undefined} className={isReady ? ibmPlexSansThai.variable : undefined}>
      <body>
        {isReady ? (
          <I18nProvider>
            <MyNav />
            {children}
          </I18nProvider>
        ) : null}
      </body>
    </html>
  );
}
