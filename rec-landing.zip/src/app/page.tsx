"use client"
function Page() {

  return (
    <div>
      sdfsdfsdf
    </div>
  );
}

export default Page;