(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_eb593877._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_eb593877._.js",
  "chunks": [
    "static/chunks/node_modules_cross-fetch_dist_browser-ponyfill_4cab1867.js",
    "static/chunks/_5a34ce03._.js"
  ],
  "source": "dynamic"
});
