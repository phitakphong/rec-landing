(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_de3d1c4e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_de3d1c4e._.js",
  "chunks": [
    "static/chunks/node_modules_cross-fetch_dist_browser-ponyfill_063f2f87.js",
    "static/chunks/node_modules_7fef3292._.js",
    "static/chunks/_17a63fac._.js"
  ],
  "source": "dynamic"
});
