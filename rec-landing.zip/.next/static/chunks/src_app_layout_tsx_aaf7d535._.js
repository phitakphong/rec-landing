(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__cb72e326._.js",
    "static/chunks/node_modules_1785f186._.js",
    "static/chunks/[root of the server]__1d7c3b4d._.js",
    "static/chunks/[root of the server]__9ce2c959._.css"
  ],
  "source": "dynamic"
});
