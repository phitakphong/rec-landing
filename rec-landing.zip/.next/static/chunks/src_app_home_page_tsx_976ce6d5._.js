(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_976ce6d5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_976ce6d5._.js",
  "chunks": [
    "static/chunks/node_modules_92389c31._.js",
    "static/chunks/src_app_ecf1ce51._.js"
  ],
  "source": "dynamic"
});
