(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_9771804a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_9771804a._.js",
  "chunks": [
    "static/chunks/_367d1e4f._.js"
  ],
  "source": "dynamic"
});
