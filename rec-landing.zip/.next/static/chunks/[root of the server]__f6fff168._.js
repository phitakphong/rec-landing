(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/[root of the server]__f6fff168._.js", {

"[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_61dcf9ba._.js",
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ad2025dc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/node_modules/cross-fetch/dist/browser-ponyfill.js [app-client] (ecmascript, async loader)": (() => {{

throw new Error("An error occurred while generating the chunk item [project]/node_modules/cross-fetch/dist/browser-ponyfill.js [app-client] (ecmascript, async loader)\n\nCaused by:\n- Cell CellId { type_id: ValueTypeId { id: 220, name: \"turbopack-core@TODO::::chunk::available_modules::AvailableModulesSet\" }, index: 0 } no longer exists in task <BrowserChunkingContext as ChunkingContext>::chunk_group (no cell of this type exists)\n\nDebug info:\n- An error occurred while generating the chunk item [project]/node_modules/cross-fetch/dist/browser-ponyfill.js [app-client] (ecmascript, async loader)\n- Execution of <AsyncLoaderChunkItem as EcmascriptChunkItem>::content failed\n- Execution of AsyncLoaderChunkItem::chunks_data failed\n- Execution of AsyncLoaderChunkItem::chunks failed\n- Execution of AvailableModules::get failed\n- Cell CellId { type_id: ValueTypeId { id: 220, name: \"turbopack-core@TODO::::chunk::available_modules::AvailableModulesSet\" }, index: 0 } no longer exists in task <BrowserChunkingContext as ChunkingContext>::chunk_group (no cell of this type exists)");

}}),
}]);