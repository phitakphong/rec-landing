(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_5dfab1ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_5dfab1ad._.js",
  "chunks": [
    "static/chunks/node_modules_cross-fetch_dist_browser-ponyfill_800de88f.js",
    "static/chunks/node_modules_9ec67617._.js",
    "static/chunks/_17a63fac._.js"
  ],
  "source": "dynamic"
});
