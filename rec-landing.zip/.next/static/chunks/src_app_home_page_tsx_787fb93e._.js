(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_787fb93e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_787fb93e._.js",
  "chunks": [
    "static/chunks/node_modules_cross-fetch_dist_browser-ponyfill_81d869a9.js",
    "static/chunks/node_modules_d547fabe._.js",
    "static/chunks/_17a63fac._.js"
  ],
  "source": "dynamic"
});
