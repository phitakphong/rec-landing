(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_51928a6d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_51928a6d._.js",
  "chunks": [
    "static/chunks/node_modules_cross-fetch_dist_browser-ponyfill_5000b3ec.js",
    "static/chunks/node_modules_de96f7d4._.js",
    "static/chunks/_17a63fac._.js"
  ],
  "source": "dynamic"
});
